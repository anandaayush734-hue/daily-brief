/* The Daily Brief — reusable view components.
 * Every component is a pure function: data in, HTML string out.
 * All text from the data files is escaped, so pipeline content can never inject markup.
 */
(function (global) {
  "use strict";

  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

  const safeUrl = (u) => (/^https?:\/\//i.test(String(u || "")) ? esc(u) : "#");

  // Link to the source when it has a real web address; plain text otherwise.
  const SourceLink = (src) => (src && /^https?:\/\//i.test(String(src.url || ""))
    ? `<a href="${esc(src.url)}" target="_blank" rel="noopener noreferrer">${esc(src.name || "Source")}</a>`
    : esc(src?.name || "No external source"));

  let ctx = { site: null, tz: "Asia/Kolkata", locale: "en-IN" };
  function configure(site) {
    ctx = { site, tz: site.timezone || "Asia/Kolkata", locale: site.locale || "en-IN", tzLabel: site.timezone_label || "" };
  }

  function fmtDate(iso, opts) {
    if (!iso) return "";
    const d = new Date(iso.length === 10 ? iso + "T12:00:00+05:30" : iso);
    return new Intl.DateTimeFormat(ctx.locale, { timeZone: ctx.tz, ...opts }).format(d);
  }
  const fmtLong = (iso) => fmtDate(iso, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const fmtShort = (iso) => fmtDate(iso, { day: "numeric", month: "short", year: "numeric" });
  const fmtTime = (iso) => fmtDate(iso, { hour: "2-digit", minute: "2-digit", hour12: false }) + (ctx.tzLabel ? " " + ctx.tzLabel : "");
  const fmtStamp = (iso) => `${fmtShort(iso)}, ${fmtTime(iso)}`;

  const sectionOf = (slug) => (ctx.site?.sections || []).find((s) => s.slug === slug) || { slug, name: slug, short: slug };
  const articleHref = (date, id) => `#/edition/${date}/article/${encodeURIComponent(id)}`;
  const sectionHref = (date, slug) => `#/edition/${date}/section/${slug}`;

  function Badge(verification) {
    const status = verification?.status || "unverified";
    const meta = ctx.site?.verification_statuses?.[status] || { label: status, description: "" };
    return `<span class="badge badge--${esc(status)}" title="${esc(meta.description)}">${esc(meta.label)}</span>`;
  }

  function Figures(list) {
    if (!list?.length) return "";
    return `<dl class="figures">${list.map((f) =>
      `<div><dt>${esc(f.label)}</dt><dd>${esc(f.value)}</dd></div>`).join("")}</dl>`;
  }

  /**
   * ArticleCard — the one card used everywhere.
   * variant: "lead" | "rail" | "standard" | "compact" | "analysis" | "result"
   */
  function ArticleCard(a, { date, variant = "standard", rank, highlight, opening = false } = {}) {
    const href = articleHref(date || a.published_at.slice(0, 10), a.id);
    const hl = (s) => (highlight ? highlightText(s, highlight) : esc(s));
    const showWhy = variant !== "compact" && variant !== "result";
    const showSource = variant !== "compact";
    return `
<article class="card card--${variant}">
  ${variant === "rail" && rank ? `<span class="rank" aria-label="Rank ${rank}">${rank}</span>` : ""}
  <div class="card__meta">
    <a class="card__kicker" href="${sectionHref(date, a.section)}">${esc(a.category || sectionOf(a.section).short)}</a>
    ${Badge(a.verification)}
  </div>
  <h3 class="card__headline"><a href="${href}">${hl(a.headline)}</a></h3>
  ${variant === "lead" && a.dek ? `<p class="card__dek">${esc(a.dek)}</p>` : ""}
  ${variant === "analysis" ? `<p class="card__byline">${esc(a.author || "")}</p>` : ""}
  <p class="card__summary">${hl(a.summary)}</p>
  ${variant === "lead" ? Figures(a.key_figures) : ""}
  ${opening ? (a.body || []).filter((b) => typeof b === "string").slice(1, 3).map((p) => `<p class="card__opening">${esc(p)}</p>`).join("") + `<a class="card__more" href="${href}">Continue reading →</a>` : ""}
  ${showWhy && a.why_it_matters ? `<p class="card__why"><b>Why it matters</b>${esc(a.why_it_matters)}</p>` : ""}
  <div class="card__foot">
    <time datetime="${esc(a.published_at)}">${esc(fmtStamp(a.published_at))}</time>
    ${showSource && a.source ? `<span>Source: ${SourceLink(a.source)}</span>` : ""}
    ${variant === "result" ? `<span>${esc(sectionOf(a.section).name)}</span>` : ""}
  </div>
</article>`;
  }

  function highlightText(text, q) {
    const safe = esc(text);
    const terms = q.trim().split(/\s+/).filter((t) => t.length > 1).map((t) => esc(t).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    if (!terms.length) return safe;
    return safe.replace(new RegExp(`(${terms.join("|")})`, "gi"), "<mark>$1</mark>");
  }

  function Body(blocks) {
    return (blocks || []).map((b) => {
      if (typeof b === "string") return `<p>${esc(b)}</p>`;
      switch (b.type) {
        case "h2": return `<h2>${esc(b.text)}</h2>`;
        case "quote": return `<blockquote>${esc(b.text)}${b.cite ? `<cite>${esc(b.cite)}</cite>` : ""}</blockquote>`;
        case "list": return `<ul>${(b.items || []).map((i) => `<li>${esc(i)}</li>`).join("")}</ul>`;
        default: return `<p>${esc(b.text)}</p>`;
      }
    }).join("");
  }

  function Implications(list) {
    if (!list?.length) return "";
    return `<dl class="implications">${list.map((i) =>
      typeof i === "string" ? `<div><dt>—</dt><dd>${esc(i)}</dd></div>`
        : `<div><dt>${esc(i.label)}</dt><dd>${esc(i.text)}</dd></div>`).join("")}</dl>`;
  }

  function SourceBox(a) {
    const v = a.verification || {};
    const src = a.source || {};
    return `
<aside class="sourcebox" aria-label="Source and verification">
  <h2>Source &amp; verification</h2>
  <dl>
    <dt>Original source</dt><dd>${SourceLink(src)}</dd>
    <dt>Source published</dt><dd>${src.published_at ? esc(fmtStamp(src.published_at)) : "Not recorded"}</dd>
    <dt>Status</dt><dd>${Badge(v)}${v.checked_at ? ` · checked ${esc(fmtStamp(v.checked_at))}` : ""}${v.checked_by ? ` by ${esc(v.checked_by)}` : ""}</dd>
    ${v.notes ? `<dt>Notes</dt><dd>${esc(v.notes)}</dd>` : ""}
  </dl>
</aside>`;
  }

  function Watchlist(items) {
    if (!items?.length) return `<p class="empty">No scheduled events for tomorrow in this edition.</p>`;
    const order = { high: 0, medium: 1, low: 2 };
    const sorted = [...items].sort((x, y) => (order[x.importance] ?? 3) - (order[y.importance] ?? 3) || String(x.time).localeCompare(String(y.time)));
    return `
<div class="table-scroll">
<table class="watch">
  <thead><tr><th scope="col">Time (${esc(ctx.tzLabel || ctx.tz)})</th><th scope="col">Event</th><th scope="col">Type</th><th scope="col">Region</th><th scope="col">Importance</th><th scope="col">Status</th></tr></thead>
  <tbody>
  ${sorted.map((w) => `
    <tr>
      <td class="time">${esc(w.time || "TBC")}<div class="w-desc">${esc(fmtDate(w.date, { day: "numeric", month: "short" }))}</div></td>
      <td><div class="w-title">${w.source?.url ? `<a href="${safeUrl(w.source.url)}" target="_blank" rel="noopener noreferrer">${esc(w.title)}</a>` : esc(w.title)}</div>
          ${w.description ? `<div class="w-desc">${esc(w.description)}</div>` : ""}</td>
      <td>${esc(w.category)}</td>
      <td>${esc(w.region)}</td>
      <td><span class="imp" data-level="${esc(w.importance)}" aria-label="${esc(w.importance)} importance" title="${esc(w.importance)}"><i></i><i></i><i></i></span></td>
      <td>${Badge(w.verification)}</td>
    </tr>`).join("")}
  </tbody>
</table>
</div>`;
  }

  global.DB = Object.assign(global.DB || {}, {
    components: { ArticleCard, Badge, Body, Implications, SourceBox, Watchlist, Figures },
    util: { SourceLink, esc, safeUrl, fmtDate, fmtLong, fmtShort, fmtTime, fmtStamp, sectionOf, articleHref, sectionHref, highlightText, configure },
  });
})(window);

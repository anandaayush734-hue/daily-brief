/* The Daily Brief — data loading, routing and page views.
 *
 * Data flow:  data/site.json  →  data/editions.json (manifest)  →  data/editions/<date>.json
 * Routes (hash-based, so the site runs on any static host):
 *   #/                                 latest published edition
 *   #/edition/2026-10-11               a specific edition
 *   #/edition/<date>/section/<slug>    every story in one section
 *   #/edition/<date>/article/<id>      article page
 *   #/archive                          previous editions
 *   #/search/<query>                   search across all published editions
 */
(function () {
  "use strict";
  const { ArticleCard, Body, Implications, SourceBox, Watchlist } = DB.components;
  const U = DB.util;
  const esc = U.esc;
  const DATA_ROOT = "data";

  /* ---------------- Data store ---------------- */
  // If a build step embedded the data (window.DAILY_BRIEF_BUNDLE), use it; otherwise fetch the JSON files.
  const bundle = window.DAILY_BRIEF_BUNDLE || null;
  const cache = new Map();
  async function getJSON(path) {
    if (cache.has(path)) return cache.get(path);
    const p = bundle
      ? Promise.resolve(bundle[path] ?? Promise.reject(new Error(`Missing ${path} in bundle`)))
      : fetch(`${DATA_ROOT}/${path}`, { cache: "no-cache" }).then((r) => {
          if (!r.ok) throw new Error(`${path}: HTTP ${r.status}`);
          return r.json();
        });
    cache.set(path, p);
    return p;
  }

  // Scheduled publishing: an edition is visible once status is "published",
  // or status is "scheduled" and its publish time has passed. Drafts never show.
  const isLive = (e, now = Date.now()) =>
    (e.status === "published" || e.status === "scheduled") && Date.parse(e.published_at) <= now;

  const Store = {
    site: () => getJSON("site.json"),
    async editions() {
      const m = await getJSON("editions.json");
      return m.editions.filter((e) => isLive(e)).sort((a, b) => b.date.localeCompare(a.date));
    },
    async edition(date) {
      const list = await this.editions();
      const entry = date ? list.find((e) => e.date === date) : list[0];
      if (!entry) return null;
      const ed = await getJSON(entry.path);
      return { ...ed, _entry: entry };
    },
  };

  /* ---------------- Shell ---------------- */
  const $ = (sel) => document.querySelector(sel);
  let SITE = null;
  let currentEdition = null;

  function renderMasthead(ed, activeSlug) {
    const total = ed?.articles?.length || 0;
    const counts = {};
    (ed?.articles || []).forEach((a) => { const s = a.verification?.status || "unverified"; counts[s] = (counts[s] || 0) + 1; });
    const ledger = Object.entries(counts).map(([s, n]) => `${n} ${(SITE.verification_statuses[s]?.label || s).toLowerCase()}`).join(" · ");
    $("#masthead").innerHTML = `
<div class="wrap">
  <div class="dateline label">
    <span>${ed ? esc(U.fmtLong(ed.date)) : ""}</span>
    <span class="mono">${esc(SITE.volume)} · No. ${ed ? esc(ed.edition_number) : "—"}</span>
    <span>${total} stories${ledger ? ` · ${esc(ledger)}` : ""}</span>
  </div>
  <div class="nameplate">
    <a href="#/"><h1>The Daily <em>Brief</em></h1></a>
    <p class="tagline">${esc(SITE.tagline)}</p>
  </div>
  <div class="navbar">
    <nav class="sections-nav" aria-label="Sections">
      <a href="#/" ${!activeSlug ? 'aria-current="page"' : ""}>Front page</a>
      ${SITE.sections.map((s) => `<a href="${U.sectionHref(ed?.date, s.slug)}" ${activeSlug === s.slug ? 'aria-current="page"' : ""}>${esc(s.short)}</a>`).join("")}
      <a href="#/archive" ${activeSlug === "archive" ? 'aria-current="page"' : ""}>Archive</a>
    </nav>
    <form class="search" role="search" id="search-form">
      <label for="q" class="skip">Search stories</label>
      <input id="q" name="q" type="search" placeholder="Search stories" autocomplete="off">
      <button type="submit">Search</button>
    </form>
    <button class="theme-toggle" id="theme-toggle" type="button" aria-label="Switch colour theme">Theme</button>
  </div>
  ${ed?.is_demo ? `<div class="notice" role="note"><strong>Demonstration edition</strong><span>${esc(ed.editor_note || "Stories in this edition are fictional and exist only to demonstrate the layout.")}</span></div>` : ""}
</div>`;
    $("#search-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const q = $("#q").value.trim();
      if (q) location.hash = `#/search/${encodeURIComponent(q)}`;
    });
    $("#theme-toggle").addEventListener("click", toggleTheme);
  }

  function toggleTheme() {
    const root = document.documentElement;
    const dark = root.dataset.theme ? root.dataset.theme === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    root.dataset.theme = dark ? "light" : "dark";
    try { localStorage.setItem("db-theme", root.dataset.theme); } catch (_) {}
  }
  try { const t = localStorage.getItem("db-theme"); if (t) document.documentElement.dataset.theme = t; } catch (_) {}

  function renderFooter() {
    $("#footer").innerHTML = `
<div class="wrap footer">
  <strong>The Daily Brief</strong>
  <p>A personal digest of finance, markets and policy. Every story links to its original source and carries a verification status. Summaries are not investment advice.</p>
  <nav><a href="#/">Today</a> · <a href="#/archive">Previous editions</a></nav>
</div>`;
  }

  const main = () => $("#main");
  const setTitle = (t) => { document.title = t ? `${t} — The Daily Brief` : "The Daily Brief"; };

  /* ---------------- Views ---------------- */
  function bySection(ed, slug, excludeFront = true) {
    return ed.articles
      .filter((a) => a.section === slug && (!excludeFront || !a.front_page_rank))
      .sort((a, b) => b.published_at.localeCompare(a.published_at));
  }

  function viewHome(ed) {
    const d = ed.date;
    const front = ed.articles.filter((a) => a.front_page_rank).sort((a, b) => a.front_page_rank - b.front_page_rank).slice(0, 5);
    const out = [];
    for (const block of SITE.homepage) {
      if (block.type === "front" && front.length) {
        const [lead, ...rail] = front;
        out.push(`
<section class="band" aria-labelledby="h-front">
  <div class="band__head"><div class="band__title"><h2 id="h-front">${esc(block.title)}</h2><p>The ${front.length} stories that matter most this morning.</p></div></div>
  <div class="front">
    <div class="front__lead">${ArticleCard(lead, { date: d, variant: "lead", opening: true })}</div>
    <div class="front__rail">${rail.map((a, i) => ArticleCard(a, { date: d, variant: "rail", rank: i + 2 })).join("")}</div>
  </div>
</section>`);
      } else if (block.type === "section") {
        const s = U.sectionOf(block.slug);
        const items = bySection(ed, block.slug).slice(0, 3);
        if (!items.length) continue;
        out.push(`
<section class="band" aria-labelledby="h-${s.slug}">
  <div class="band__head">
    <div class="band__title"><h2 id="h-${s.slug}">${esc(s.name)}</h2><p>${esc(s.description)}</p></div>
    <a class="more" href="${U.sectionHref(d, s.slug)}">All ${esc(s.short)} stories →</a>
  </div>
  <div class="grid3" style="--cols:${Math.min(items.length, 3)}">${items.map((a) => ArticleCard(a, { date: d })).join("")}</div>
</section>`);
      } else if (block.type === "analysis") {
        const s = U.sectionOf(block.slug);
        const items = bySection(ed, block.slug, false);
        if (!items.length) continue;
        out.push(`
<section class="band corner" aria-labelledby="h-analysis">
  <div class="band__head"><div class="band__title"><h2 id="h-analysis">${esc(s.name)}</h2><p>${esc(s.description)}</p></div></div>
  <div class="grid2">${items.slice(0, 2).map((a) => ArticleCard(a, { date: d, variant: "analysis" })).join("")}</div>
</section>`);
      } else if (block.type === "learn") {
        const s = U.sectionOf(block.slug);
        const a = bySection(ed, block.slug, false)[0];
        if (!a) continue;
        out.push(`
<section class="band" aria-labelledby="h-learn">
  <div class="band__head"><div class="band__title"><h2 id="h-learn">${esc(s.name)}</h2><p>${esc(s.description)}</p></div></div>
  <div class="learn">
    ${ArticleCard(a, { date: d, variant: "lead" })}
    ${a.key_takeaways?.length ? `<aside class="takeaways"><h3>Key takeaways</h3><ol>${a.key_takeaways.map((t) => `<li>${esc(t)}</li>`).join("")}</ol></aside>` : ""}
  </div>
</section>`);
      } else if (block.type === "watchlist") {
        const nextDay = ed.watchlist?.[0]?.date;
        out.push(`
<section class="band" aria-labelledby="h-watch">
  <div class="band__head"><div class="band__title"><h2 id="h-watch">${esc(block.title)}</h2><p>${nextDay ? `Scheduled for ${esc(U.fmtLong(nextDay))}. Times are ${esc(SITE.timezone_label)}.` : "Economic releases, results and events to watch."}</p></div></div>
  ${Watchlist(ed.watchlist)}
</section>`);
      }
    }
    main().innerHTML = `<div class="wrap">${out.join("")}</div>`;
    setTitle(ed === currentEdition ? "" : `Edition No. ${ed.edition_number}`);
  }

  function viewSection(ed, slug) {
    const s = U.sectionOf(slug);
    const items = bySection(ed, slug, false);
    main().innerHTML = `
<div class="wrap">
  <header class="page-head"><span class="label">${esc(U.fmtLong(ed.date))} · No. ${esc(ed.edition_number)}</span><h1>${esc(s.name)}</h1><p>${esc(s.description || "")}</p></header>
  <div class="results">${items.length ? items.map((a) => ArticleCard(a, { date: ed.date })).join("") : `<p class="empty">No ${esc(s.short)} stories in this edition.</p>`}</div>
</div>`;
    setTitle(s.name);
  }

  function viewArticle(ed, id) {
    const a = ed.articles.find((x) => x.id === id);
    if (!a) return viewNotFound("We couldn't find that story in this edition.");
    const s = U.sectionOf(a.section);
    const related = ed.articles.filter((x) => x.section === a.section && x.id !== a.id).slice(0, 3);
    const canPrint = window.self === window.top; // printing is blocked inside embedded previews
    main().innerHTML = `
<div class="wrap">
<article class="article">
  <nav class="crumbs" aria-label="Breadcrumb"><a href="#/edition/${ed.date}">No. ${esc(ed.edition_number)} · ${esc(U.fmtShort(ed.date))}</a><span>/</span><a href="${U.sectionHref(ed.date, a.section)}">${esc(s.name)}</a></nav>
  ${a.is_demo ? `<div class="notice" role="note"><strong>Demo story</strong><span>This article is fictional. ${esc(a.verification?.notes || "")}</span></div>` : ""}
  <header class="article__head">
    <div class="card__meta"><span class="card__kicker">${esc(a.category)}</span>${DB.components.Badge(a.verification)}</div>
    <h1>${esc(a.headline)}</h1>
    ${a.dek ? `<p class="article__dek">${esc(a.dek)}</p>` : ""}
    <div class="article__meta">
      ${a.author ? `<span>By ${esc(a.author)}</span>` : ""}
      <time datetime="${esc(a.published_at)}">Published ${esc(U.fmtStamp(a.published_at))}</time>
      ${a.updated_at ? `<time datetime="${esc(a.updated_at)}">Updated ${esc(U.fmtStamp(a.updated_at))}</time>` : ""}
      <span>Source: ${U.SourceLink(a.source)}</span>
    </div>
  </header>
  <p class="article__summary">${esc(a.summary)}</p>
  ${a.key_figures?.length ? `<div style="margin-top:20px">${DB.components.Figures(a.key_figures)}</div>` : ""}
  <div class="prose">${Body(a.body)}</div>
  ${a.key_takeaways?.length ? `<aside class="takeaways"><h3>Key takeaways</h3><ol>${a.key_takeaways.map((t) => `<li>${esc(t)}</li>`).join("")}</ol></aside>` : ""}
  <section class="callout" style="margin-top:24px"><h2>Why it matters</h2><p>${esc(a.why_it_matters)}</p></section>
  ${a.implications?.length ? `<section class="callout" style="margin-top:24px"><h2>Business &amp; financial implications</h2>${Implications(a.implications)}</section>` : ""}
  ${SourceBox(a)}
  ${a.tags?.length ? `<div class="tags">${a.tags.map((t) => `<a href="#/search/${encodeURIComponent(t)}">${esc(t)}</a>`).join("")}</div>` : ""}
  <div class="actions">
    ${canPrint ? `<button class="btn" type="button" id="print-btn">Print article</button>` : ""}
    <button class="btn" type="button" id="copy-btn">Copy link</button>
    ${/^https?:\/\//i.test(a.source?.url || "") ? `<a class="btn" href="${esc(a.source.url)}" target="_blank" rel="noopener noreferrer">Read original source</a>` : ""}
  </div>
  ${related.length ? `<section class="related band"><div class="band__head"><h2>More from ${esc(s.name)}</h2></div><div class="grid3" style="--cols:${related.length}">${related.map((r) => ArticleCard(r, { date: ed.date, variant: "compact" })).join("")}</div></section>` : ""}
</article>
</div>`;
    $("#print-btn")?.addEventListener("click", () => window.print());
    $("#copy-btn").addEventListener("click", (e) => {
      const btn = e.currentTarget;
      navigator.clipboard?.writeText(location.href).then(() => { btn.textContent = "Link copied"; }, () => { btn.textContent = "Copy failed"; });
    });
    setTitle(a.headline);
  }

  async function viewArchive() {
    const list = await Store.editions();
    const groups = {};
    list.forEach((e) => { const k = U.fmtDate(e.date, { month: "long", year: "numeric" }); (groups[k] ||= []).push(e); });
    main().innerHTML = `
<div class="wrap">
  <header class="page-head"><span class="label">Archive</span><h1>Previous editions</h1><p>${list.length} published editions. Scheduled and draft editions appear here once their publish time passes.</p></header>
  ${Object.entries(groups).map(([month, eds]) => `
  <section class="archive-month"><h2>${esc(month)}</h2>
    ${eds.map((e) => `
    <a class="archive-row" href="#/edition/${e.date}">
      <span class="no">No. ${esc(e.edition_number)}</span>
      <div><h3>${esc(e.lead_headline || "Edition")}</h3><div class="sub">${esc(U.fmtLong(e.date))} · ${e.article_count} stories</div></div>
      <span>${e.is_demo ? DB.components.Badge({ status: "demo" }) : ""}</span>
    </a>`).join("")}
  </section>`).join("")}
</div>`;
    setTitle("Previous editions");
  }

  async function viewSearch(q, sectionFilter = "") {
    const list = await Store.editions();
    const eds = await Promise.all(list.map((e) => Store.edition(e.date)));
    const terms = q.toLowerCase().split(/\s+/).filter(Boolean);
    const hits = [];
    eds.forEach((ed) => ed.articles.forEach((a) => {
      if (sectionFilter && a.section !== sectionFilter) return;
      const hay = [a.headline, a.dek, a.summary, a.why_it_matters, a.category, (a.tags || []).join(" "), a.source?.name]
        .join(" ").toLowerCase();
      if (terms.every((t) => hay.includes(t))) hits.push({ a, date: ed.date });
    }));
    hits.sort((x, y) => y.a.published_at.localeCompare(x.a.published_at));
    main().innerHTML = `
<div class="wrap">
  <header class="page-head"><span class="label">Search</span><h1>${esc(q)}</h1>
    <div class="filters">
      <label for="section-filter">Section</label>
      <select id="section-filter"><option value="">All sections</option>${SITE.sections.map((s) => `<option value="${s.slug}" ${s.slug === sectionFilter ? "selected" : ""}>${esc(s.name)}</option>`).join("")}</select>
      <span>${hits.length} result${hits.length === 1 ? "" : "s"} across ${eds.length} editions</span>
    </div>
  </header>
  <div class="results">${hits.length ? hits.map((h) => ArticleCard(h.a, { date: h.date, variant: "result", highlight: q })).join("") : `<p class="empty">No stories match “${esc(q)}”. Try a company name, a sector or a term like “IPO”.</p>`}</div>
</div>`;
    $("#section-filter").addEventListener("change", (e) => viewSearch(q, e.target.value));
    $("#q").value = q;
    setTitle(`Search: ${q}`);
  }

  function viewNotFound(msg) {
    main().innerHTML = `<div class="wrap"><header class="page-head"><h1>Not found</h1><p>${esc(msg)}</p><p><a href="#/" style="color:var(--accent)">Go to today's front page →</a></p></header></div>`;
    setTitle("Not found");
  }

  /* ---------------- Router ---------------- */
  async function route() {
    const parts = location.hash.replace(/^#\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
    try {
      if (parts[0] === "archive") { renderMasthead(currentEdition, "archive"); await viewArchive(); }
      else if (parts[0] === "search") { renderMasthead(currentEdition); await viewSearch(parts.slice(1).join("/")); }
      else {
        const date = parts[0] === "edition" ? parts[1] : null;
        const ed = date ? await Store.edition(date) : currentEdition;
        if (!ed) { renderMasthead(currentEdition); return viewNotFound(`There is no published edition for ${date}.`); }
        if (parts[2] === "article") { renderMasthead(ed, ed.articles.find((a) => a.id === parts[3])?.section); viewArticle(ed, parts[3]); }
        else if (parts[2] === "section") { renderMasthead(ed, parts[3]); viewSection(ed, parts[3]); }
        else { renderMasthead(ed); viewHome(ed); }
      }
    } catch (err) {
      console.error(err);
      main().innerHTML = `<div class="wrap"><header class="page-head"><h1>Couldn't load this page</h1><p>${esc(err.message)}. If you opened index.html directly from disk, serve the folder instead: <code>python3 -m http.server</code>.</p></header></div>`;
    }
    window.scrollTo(0, 0);
  }

  async function start() {
    try {
      SITE = await Store.site();
      U.configure(SITE);
      currentEdition = await Store.edition(null);
      renderFooter();
      window.addEventListener("hashchange", route);
      await route();
    } catch (err) {
      console.error(err);
      main().innerHTML = `<div class="wrap"><header class="page-head"><h1>Couldn't load the newspaper</h1><p>${esc(err.message)}. Serve this folder over HTTP (for example <code>python3 -m http.server 8000</code>) rather than opening the file directly.</p></header></div>`;
    }
  }
  start();
})();
